function [Kg]= elementmat( NDOF, NEN, NN, NE, ELECON, E, A, a)
C= [1 -1; -1 1];
%K= zeros(2,2);
%for i = 1: length(E)
    %K= ((E(i,1)*A(i,1))/a(i,1))*C;
%end
Kg= zeros(NN*NDOF, NN*NDOF);

for i= 1: NE
    for l= 1:NEN
        noden= ELECON(i, l);
        for k= 1:NDOF
            j= (l-1)*NDOF+k;
            LM(i,j)= NDOF*(noden-1)+k;
        end
    end
end

NEE= NEN*NDOF;
for i= 1: NE
    Ke = ((E(i)*A(i)) /a(i))*[1 -1; -1 1];
    for j= 1: NEE
        jg= LM(i,j);
        for l= 1: NEE
            lg= LM(i,l);
            Kg(jg, lg)= Kg(jg,lg)+Ke(j,l);
        end
    end
end

end