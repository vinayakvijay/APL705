function Fg= globalforce( NDOF ,NL ,NN,PLOAD)
Fg= zeros(NN*NDOF,1);
X= zeros(height(PLOAD),1);
for i= 1: height(PLOAD)
    X(i)= PLOAD(i,1);
end

for j= 1: length(X)
    a=X(j);
    Fg(a,1)= PLOAD(j,3);
    
end
