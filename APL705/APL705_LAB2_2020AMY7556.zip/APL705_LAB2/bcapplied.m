function [Fg1 Kg1]= bcapplied(ND, BC, NDOF, NN, Fg, Kg)
Kg1=zeros(NN*NDOF-height(BC), NN*NDOF-height(BC));
Fg1= zeros(height(Fg)-height(BC),1);

for i= 1:length(Kg)-height(BC)
    for j= 1:length(Kg)-height(BC)
        Kg1(i,j)=Kg(i+1, j+1);
    end
end

for l = 1:length(Kg)-height(BC)
    Fg1(l,1)=Fg(l+1,1);
end