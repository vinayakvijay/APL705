function u= getufromu1(BC, Fg, u1);
u=zeros(height(Fg),1);
for j= 1: height(BC)
    a= BC(j,1);
    for i= 1: height(BC)+height(u1)
    
        if i==a
        u(i)=0;
        end
        if i<a
            u(i)=u1(i);
        end
        if i>a
            u(i)=u1(i-1);
        end
        
    end
end