function [a, E, A]= precalc(NN,ELECON, CORD, MAT)
a = zeros(NN-1, 1);
E = zeros(NN-1, 1);
A = zeros(NN-1, 1);
    for i= 1: NN-1
        a(i)= CORD(i+1,1)-CORD(i,1);
        E(i)= MAT(i,1);
        A(i)= ELECON(i, length(ELECON));
    
    end
