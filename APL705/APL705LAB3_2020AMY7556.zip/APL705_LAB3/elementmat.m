function [Kg]= elementmat( NDOF, NEN, NN, NE, ELECON, E, A, a)
C= [1 -1; -1 1];
%K= zeros(2,2);
%for i = 1: length(E)
    %K= ((E(i,1)*A(i,1))/a(i,1))*C;
%end
Kg= zeros(NN*NDOF, NN*NDOF);

for i= 1: NE
    for l= 1:NEN
        noden= ELECON(i, l);
        for k= 1:NDOF
            j= (l-1)*NDOF+k;
            LM(i,j)= NDOF*(noden-1)+k;  %Global DOF
        end
    end
end

NEE= NEN*NDOF;
for i= 1: NE
    Ke_element = ((E(i)*A(i)) /a(i))*[1 -1; -1 1];
    theta= ELECON(i, width(ELECON));
    L= [cos(theta) sin(theta) 0 0; 0 0 cos(theta) sin(theta)];
    Ke= L'*Ke_element*L;
    for j= 1: NEE
        jg= LM(i,j);
        for l= 1: NEE
            lg= LM(i,l);
            Kg(jg, lg)= Kg(jg,lg)+Ke(j,l);
        end
    end
end

end