function u= getufromu1(BC, Fg, u1, NDOF);
u=zeros(height(Fg),1);
for j= 1: height(BC)
    a= BC(j,1);
    b= BC(j,2);
    location(j,1)= (a-1)*NDOF+b;
end

b= [0;0];
k=2;
location= [location(1:k,:); b; location(k+1:end, :)];
for i= 1:height(Fg)
if i==location(i,1)
        u(i)=0;
end
if i ~= location(i,1)
            u(i)=u1(i-2);
end
end
location = zeros(6,1);

