function Fg= globalforce( NDOF ,NL ,NN,PLOAD)
Fg= zeros(NN*NDOF,1);
X= zeros(height(PLOAD),2);
for i= 1: height(PLOAD)
    for j= 1: NDOF
        X(i,j)= PLOAD(i,j);
    end
end

for j= 1: height(X)
        k= 1;
        a=X(j,k);
        b=X(j,k+1);
        Fg(a+b,1)= PLOAD(j,3);
 end
