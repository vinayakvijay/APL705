function [Fg1 Kg1]= bcapplied(ND, BC, NDOF, NN, Fg, Kg)


        
Kg2=Kg;

for i= 1: height(BC)
   a= BC(i,1);
   b= BC(i,2);
   eleminate= (a-1)*NDOF+b;  %gives the row and column which need to be eliminated.
   Kg2(eleminate,:)=[0]; %makes the rows and columns corresponding to natural BCs zero in the global stiffness matrix
   Kg2(:,eleminate)=[0];
end

idx2keep_columns = sum(abs(Kg2),1)>0 ; %deleting zero rows and columns from the global stiffness matrix.
idx2keep_rows    = sum(abs(Kg2),2)>0 ;

Kg1 = Kg2(idx2keep_rows,idx2keep_columns) ;

idx_nonzerolines = sum(abs(Fg),2)>0 ;
Fg1 = Fg(idx_nonzerolines,:);
