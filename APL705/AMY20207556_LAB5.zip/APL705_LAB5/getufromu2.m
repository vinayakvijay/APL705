function u= getufromu2(BC, Fg, u1, NDOF);
u=zeros(height(Fg),1);
%a1=0.5;
for j= 1: height(BC)
    a1= BC(j,1);
    b= BC(j,2);
    location(j,1)= (a1-1)*NDOF+b;
end

b= zeros(height(Fg)-height(BC)-1,1);
k=2;
location= [location(1:k,:); b; location(k+1:end, :); 0];
for i= 1:height(Fg)
if i==location(i,1)
        u(i)=0;
end
if i ~= location(i,1)
            u(i)=u1(i-3);
end
end
location = zeros(6,1);

u= -u./10;





