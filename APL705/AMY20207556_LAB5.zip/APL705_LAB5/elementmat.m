function [Kg, Fg]= elementmat( NDOF, NEN, NN, NE, ELECON, E, a, NGP, W)

%K= zeros(2,2);
%for i = 1: length(E)
    %K= ((E(i,1)*A(i,1))/a(i,1))*C;
%end
syms x Ne xi;
b=.040;
h= .060- .030*x;
q= 1500+1500*x;
I= (b*h^3)/12;

Ne= [1- ((3*x^2)./(a.^2))+ ((2*x^3)./(a.^3)) (x-(2*x^2)./a)+((x^3)./(a.^2)) ((3*x^2)./(a.^2))-((2*x^3)./(a.^3)) ((x^3)./(a.^2)-(x^2)./(a))];
Be= diff(diff(Ne));
Kg= zeros(NN*NDOF, NN*NDOF);
Fg= zeros(NN*NDOF, 1);

for i= 1: NE
    for l= 1:NEN
        noden= ELECON(i, l);
        for k= 1:NDOF
            j= (l-1)*NDOF+k;
            LM(i,j)= NDOF*(noden-1)+k;  %Global DOF
        end
    end
end

NEE= NEN*NDOF;
Ke_num= zeros( NEE, NEE);
fe_numerical = zeros( NEE,1);
for i= 1: NE
    x= ((1+xi)*a(i))/2;
    x_mod= (i-1)*a(i)+ ((1+xi)/2)*a(i);
    I_mod= subs(I, x_mod);
    Be_num= subs(Be,x);
    X= (Be_num'*E*I_mod*Be_num)*a(i)/2;
    Ne_num= subs(Ne,x);
    q_num= subs(q, x_mod);
    fe_num= Ne_num'*q_num;
    %CALCULATION OF stiffness and load vector for 3 gauss points
    for j= 1:3
        
        temp= double(subs(X, NGP(j)));
        temp2= double(subs(fe_num, NGP(j)));
        Ke_num= Ke_num+ W(j)*temp;
        fe_numerical= fe_numerical+W(j)*temp2;
    end
    Ke= double(Ke_num)*a(i)/2;
    fe= double(fe_numerical)*a(i)/2;
    for j= 1: NEE
        jg= LM(i,j);
        for l= 1: NEE
            lg= LM(i,l);
            Kg(jg, lg)= Kg(jg,lg)+Ke(j,l);
            Fg(jg)= Fg(jg)+fe(j);
        end
    end
end

end