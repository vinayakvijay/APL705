%ALL UNITS ARE IN NEWTON & MM.
clear; clc;
fileINPUT = fopen('APL705_Lab5_1.txt', 'r');       %Reading and initialising matrix data from .txt file.
[NN NE NM NP NIP NDIM NEN NDOF ND NL NEUDL NRC CORD ELECON BC LOAD_COEFF MAT]= txtRd(fileINPUT);     %Reading and initialising matrix data from .txt file.

NGP = [-0.7745966692414834; 0; 0.7745966692414834];
W= [ 0.5555555555555556; 0.8888888888888889 ; 0.5555555555555556];
[a E]= precalc(NN,ELECON, CORD, MAT);

[Kg, Fg]= elementmat( NDOF, NEN, NN, NE, ELECON, E, a, NGP, W);
%Fg= globalforce( NDOF ,NL ,NN,PLOAD);
[Fg1 Kg1]= bcapplied(ND, BC, NDOF, NN, Fg, Kg);
u1=linsolve(Kg1, Fg1);

u= getufromu1(BC, Fg, u1, NDOF); %displacement at global nodes.
%u= getufromu2(BC, Fg, u1, NDOF);  % FOR Fixed Pinned condition uncomment
%this
R= Kg*u-Fg;  %Reaction force.

sigma_max_A= -R(2)*0.03/(0.04*0.06^3/12);

%The relevant data that needs to be plotted has been added added to
%.mat files that can be seen in the zip and compiled into a RESULT_CANTILEVER.mat OR RESULT_FIXPIN file
%for every boundary condition
%ALL UNITS ARE IN NEWTON & MM.

dat= load('RESULT_CANTILEVER.mat');
elem= [1; 2;4;6];
subplot(2, 1, 1)

plot(elem, -dat.data.deflection, 'o');
xlabel('No of elements');
ylabel('Deflection in meter CANTILEVER');
subplot(2, 1, 2)

plot(elem, -dat.data.sigma_max_A, 'o');
xlabel('No of elements');
ylabel('Maximum stress at A CANTILEVER');



















clear u1;