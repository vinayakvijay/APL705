%ALL UNITS ARE IN NEWTON & metre.
clear; clc;
fileINPUT = fopen('APL705_Lab8.txt', 'r'); %Reading and initialising matrix data from .txt file.

[NN NE NM NP NIP NDIM NEN NDOF ND NL NEUDL NRC CORD ELECON BC PLOAD UDL MAT t mu]= textRd(fileINPUT);     %Reading and initialising matrix data from .txt file.



[E ]= precalc( MAT, NE, mu);

Kg= elementmat( NDOF, NEN, NN, NE, ELECON, E, NDIM, MAT, CORD, mu,t);

Fg= globalforce( NDOF ,NL ,NN,PLOAD, NE, NEN, ELECON, NEUDL, UDL, CORD);
[Fg1 Kg1]= bcapplied(ND, BC, NDOF, NN, Fg, Kg);
u1=linsolve(Kg1, Fg1);

u= getufromu1(BC, Fg, u1, NDOF, NN); %displacement at global nodes.

R= Kg*u-Fg;   %Reaction force.


%ALL UNITS ARE IN NEWTON & metre.
