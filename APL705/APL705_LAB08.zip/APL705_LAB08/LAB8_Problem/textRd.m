%A and B are matrices of Question 1. C & D are matrices for Question 2.
function [NN NE NM NP NIP NDIM NEN NDOF ND NL NEUDL NRC CORD ELECON BC PLOAD UDL MAT t mu]= textRd(fileINPUT)
size=1;
formatSP1= '%d';
formatSP2 = '%f';
%initialising rows and columns in different matrices from txt file.
NN= fscanf(fileINPUT, formatSP1, size);
NE= fscanf(fileINPUT, formatSP1, size);
NM= fscanf(fileINPUT, formatSP1, size);
NP= fscanf(fileINPUT, formatSP1, size);
NIP= fscanf(fileINPUT, formatSP1, size);
NDIM= fscanf(fileINPUT, formatSP1, size);
NEN= fscanf(fileINPUT, formatSP1, size);
NDOF= fscanf(fileINPUT, formatSP1, size);
ND= fscanf(fileINPUT, formatSP1, size);
NL= fscanf(fileINPUT, formatSP1, size);
NEUDL= fscanf(fileINPUT, formatSP1, size);
NRC= fscanf(fileINPUT, formatSP1, size);
t= fscanf(fileINPUT, formatSP2, size);
mu= fscanf(fileINPUT, formatSP2, size);
CORD= fscanf(fileINPUT, formatSP2, ([NN NDIM]));
ELECON= fscanf(fileINPUT, formatSP2, ([NE NEN+NRC]));
BC= fscanf(fileINPUT, formatSP2, ([ND 3]));
PLOAD= fscanf(fileINPUT, formatSP2, ([NL 3]));
UDL= fscanf(fileINPUT, formatSP2, ([NEUDL 3]));
MAT= fscanf(fileINPUT, formatSP2, ([NM NP]));
