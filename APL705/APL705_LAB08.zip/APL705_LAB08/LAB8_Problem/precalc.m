function [E]= precalc (MAT, NE, mu)

E = zeros(NE, 1);
D = zeros(NE, 1);

%I = zeros(NN-1, 1);
    for i= 1: NE
        %a(i)= sqrt(abs((CORD(i+1,1)-CORD(i,1)).^2+(CORD(i+1,2)-CORD(i,2)).^2));
        E(i)= MAT(1,1);
        
        
        
    end
 
 
