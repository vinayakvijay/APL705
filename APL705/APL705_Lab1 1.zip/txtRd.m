%A and B are matrices of Question 1. C & D are matrices for Question 2.
function [rowA colA rowB colB rowC colC rowD colD A B C D]= txtRd(fileINPUT)
size=1;
formatSP1= '%d';
formatSP2 = '%f';
%initialising rows and columns in different matrices from txt file.
rowA= fscanf(fileINPUT, formatSP1, size);
colA= fscanf(fileINPUT, formatSP1, size);
rowB= fscanf(fileINPUT, formatSP1, size);
colB= fscanf(fileINPUT, formatSP1, size);
rowC= fscanf(fileINPUT, formatSP1, size);
colC= fscanf(fileINPUT, formatSP1, size);
rowD= fscanf(fileINPUT, formatSP1, size);
colD= fscanf(fileINPUT, formatSP1, size);
sizeA= [rowA colA];
sizeB = [rowB colB];
sizeC = [rowC colC];
sizeD = [rowD colD];

%initialising matrices
A= fscanf(fileINPUT, formatSP2, sizeA);
B= fscanf(fileINPUT, formatSP2, sizeB);
C= fscanf(fileINPUT, formatSP2, sizeC);
D= fscanf(fileINPUT, formatSP2, sizeD);
 