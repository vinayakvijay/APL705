clear all; clc;
fileINPUT = fopen('APL705_Lab1.txt', 'r');       %Reading and initialising matrix data from .txt file.
[rowA colA rowB colB rowC colC rowD colD A B C D]= txtRd(fileINPUT);     %Reading and initialising matrix data from .txt file.

%Question 1a
sum= A+B;
Diff= A-B;          
product= A*B;               
product2= A'*B;
inverseA= inv(A);


%Question 1b
eigen_A= eig(A);
eigen_B= eig(B);              

%Question2
X= linsolve(C,D);    
%OR
%X= inv(C)*D;
