fileINPUT = fopen('APL705_Lab4.txt', 'r');       %Reading and initialising matrix data from .txt file.
[NE, NN, NDOF, a, E, b, h, NGP2, NGP3, NGP4, W2, W3, W4, q, load_x]= txtRead(fileINPUT); 
[c]= load_function(q, load_x); %coefficients for polynomial of load function.

syms x Ne xi;
I= (b*h^3)/12;
Ne= [1- ((3*x^2)/(a^2))+ ((2*x^3)/(a^3)) (x-(2*x^2)/a)+((x^3)/(a^2)) ((3*x^2)/(a^2))-((2*x^3)/(a^3)) ((x^3)/(a^2)-(x^2)/(a))];
Be= diff(diff(Ne));
X= (Be'*E*I*Be);
Ke1= int( X, 0, 1);
Ke= double(Ke1)  %converts symbolic expression back to numerical value.


q_x= poly2sym(flip(c), x);  %load function for UVL
fe1= int(Ne'*q_x, 0, 1);
fe= double(fe1)  %converts symbolic expression back to numerical value.


Ke_num_NGP2= zeros(NN*NDOF, NN*NDOF); %Numerical integration elemental stiffness value for 2 gauss points
Ke_num_NGP3= zeros(NN*NDOF, NN*NDOF); %Numerical integration elemental stiffness value for 3 gauss points
Ke_num_NGP4= zeros(NN*NDOF, NN*NDOF); %Numerical integration elemental stiffness value for 4 gauss points

fe_numerical_NGP3= zeros(NN*NDOF,1); %Numerical integration force load vector for 3 gauss points
fe_numerical_NGP4= zeros(NN*NDOF,1); %Numerical integration force load vector for 4 gauss points

%NUMERICAL INTEGRATION SECTION
x= ((1+xi)*a)/2;
X_num= subs(X, x);
fe_num= subs(Ne'*q_x, x);



% CALCULATION OF stiffness for 2 gauss points
% Since the load vector polynomial is of order 4, it needs a minimum of 3 gauss points
for j= 1:length(NGP2)
    NGP2(j);
    W2(j);
    temp= double(subs(X_num, NGP2(j)));
    Ke_num_NGP2= Ke_num_NGP2+ W2(j)*temp;
    temp=0;
end
Ke_num_NGP2= Ke_num_NGP2*a/2;


%CALCULATION OF stiffness and load vector for 3 gauss points
for j= 1:length(NGP3)
    NGP3(j);
    W3(j);
    temp= double(subs(X_num, NGP3(j)));
    temp2= double(subs(fe_num, NGP3(j)));
    Ke_num_NGP3= Ke_num_NGP3+ W3(j)*temp;
    fe_numerical_NGP3= fe_numerical_NGP3+W3(j)*temp2;
    temp=0;
end
Ke_num_NGP3= Ke_num_NGP3*a/2
fe_numerical_NGP3= fe_numerical_NGP3*a/2


%CALCULATION OF stiffness and load vector for 4 gauss points
for j= 1:length(NGP4)
    NGP4(j);
    W4(j);
    temp= double(subs(X_num, NGP4(j)));
    temp2= double(subs(fe_num, NGP4(j)));
    Ke_num_NGP4= Ke_num_NGP4+ W4(j)*temp;
    fe_numerical_NGP4= fe_numerical_NGP4+W4(j)*temp2;
    temp=0;
end
Ke_num_NGP4= Ke_num_NGP4*a/2
fe_numerical_NGP4= fe_numerical_NGP4*a/2

sgtitle('Absolute error in Elemental stiffness matrix comparision');
%AS NGP INCREASES, ERROR DECREASES.
subplot(2,2, 1);
Ke_abs1= abs(Ke-Ke_num_NGP2);
bar(Ke_abs1);
title('NGP2');
subplot(2,2,2)
Ke_abs2= abs(Ke-Ke_num_NGP3);
bar(Ke_abs2);
title('NGP3');
subplot(2,2,3)
Ke_abs3= abs(Ke-Ke_num_NGP4);
bar(Ke_abs3);
title('NGP4');
