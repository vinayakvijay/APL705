%A and B are matrices of Question 1. C & D are matrices for Question 2.
function [NE, NN, NDOF, a, E, b, h, NGP2, NGP3, NGP4, W2, W3, W4, q, load_x]= txtRead(fileINPUT)
size=1;
formatSP1= '%f';
formatSP2 = '%f';
%initialising rows and columns in different matrices from txt file.
NE= fscanf(fileINPUT, formatSP1, size);
NN= fscanf(fileINPUT, formatSP1, size);
NDOF= fscanf(fileINPUT, formatSP1, size);
a= fscanf(fileINPUT, formatSP1, size);
E= fscanf(fileINPUT, formatSP1, size);
b= fscanf(fileINPUT, formatSP1, size);
h= fscanf(fileINPUT, formatSP1, size);

NGP2= fscanf(fileINPUT, formatSP2, ([2, 1]));
NGP3= fscanf(fileINPUT, formatSP2, ([3, 1]));
NGP4= fscanf(fileINPUT, formatSP2, ([4, 1]));

W2 = fscanf(fileINPUT, formatSP2, ([2, 1])); 
W3 = fscanf(fileINPUT, formatSP2, ([3, 1]));
W4 = fscanf(fileINPUT, formatSP2, ([4, 1]));

q= fscanf(fileINPUT, formatSP2, ([2, 1]));
load_x= fscanf(fileINPUT, formatSP2, ([2, 1]));
