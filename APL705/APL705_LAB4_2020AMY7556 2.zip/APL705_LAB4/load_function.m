function[c]= load_function(q, load_x)
%x= [0 1];

%a= [a1; a2];

p_x= ones(length(load_x));
for i=1:length(load_x)
    p_x(i,2)= load_x(i);
end

c= inv(p_x)*q;


