%ALL UNITS ARE IN NEWTON & metre.
clear; clc;
fileINPUT = fopen('APL705_Lab10.txt', 'r'); %Reading and initialising matrix data from .txt file.

[NN NE NM NP NIP NDIM NEN NDOF ND NL NEUDL NRC t CORD ELECON BC PLOAD UDL MAT]= textRd(fileINPUT);     %Reading and initialising matrix data from .txt file.



[Wi Wj xii etaa N1 N2 N3 N4 D]= precalc(MAT);

[Mg Kg]= elementmat( NDOF, NEN, NN, NE, ELECON, NDIM, CORD, Wi,Wj, xii, etaa, N1, N2, N3, N4, D,t, MAT);


[Mg1 Kg1]= bcapplied(ND, BC, NDOF, NN, Mg, Kg);

omega= sort(sqrt(eig(Kg1, Mg1))/(2*pi));

fprintf('The first five natural frequencies are = ');
omega(1:5,1)

