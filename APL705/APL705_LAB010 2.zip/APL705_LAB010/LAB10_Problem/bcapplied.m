function [Mg1 Kg1]= bcapplied(ND, BC, NDOF, NN, Mg, Kg)


        
Kg2=Kg;
Mg2=Mg;
for i= 1: height(BC)
   a= BC(i,1);
   b= BC(i,2);
   eleminate= (a-1)*NDOF+b;  %gives the row and column which need to be eliminated.
   Kg2(eleminate,:)=[0]; %makes the rows and columns corresponding to natural BCs zero in the global stiffness matrix
   Kg2(:,eleminate)=[0];
   Mg2(eleminate,:)=[0]; %makes the rows and columns corresponding to natural BCs zero in the global stiffness matrix
   Mg2(:,eleminate)=[0];
end

idx2keep_columns = sum(abs(Kg2),1)>0 ; %deleting zero rows and columns from the global stiffness matrix.
idx2keep_rows    = sum(abs(Kg2),2)>0 ;

idx2keep_columns_s = sum(abs(Mg2),1)>0 ; %deleting zero rows and columns from the global stiffness matrix.
idx2keep_rows_s    = sum(abs(Mg2),2)>0 ;

Kg1 = Kg2(idx2keep_rows,idx2keep_columns) ;
Mg1 = Mg2(idx2keep_rows_s,idx2keep_columns_s) ;
