function [E, A]= precalc(NN,ELECON, CORD, MAT, NE, NEN, NDIM)

E = zeros(NE, 1);
A = zeros(NE, 1);
node_points= zeros(NE, NEN);
vertex_cords= zeros(NEN, NDIM);
x= ones(NEN,1);
%I = zeros(NN-1, 1);
    for i= 1: NE
        %a(i)= sqrt(abs((CORD(i+1,1)-CORD(i,1)).^2+(CORD(i+1,2)-CORD(i,2)).^2));
        E(i)= MAT(i);
        node_points(i, :)= ELECON(i, 1:width(ELECON)-2);
        for j=1:3
            vertex_cords(j,:) = [CORD(node_points(i,j),1); CORD(node_points(i,j),2) ];
            vert= [vertex_cords x];
            A(i)= 0.5*det(vert);
        end
            %A(i)= 
        
    end