function Fg= globalforce( NDOF ,NL ,NN,PLOAD, NE, NEN, ELECON, NEUDL, UDL, CORD)
Fg= zeros(NN*NDOF,1);

X= zeros(height(PLOAD),NDOF);

for i= 1: height(PLOAD)
    for j= 1: NDOF
        X(i,j)= PLOAD(i,j);
    end
end
for i= 1: NE
    for l= 1:NEN
        noden= ELECON(i, l);
        for k= 1:NDOF
            j= (l-1)*NDOF+k;
            LM(i,j)= NDOF*(noden-1)+k;  %Global DOF
        end
    end
end
if NEUDL == 0
    for j= 1: height(X)
        k= 1;
        a1=X(j,k);
        b=X(j,k+1);
        Fg(LM(a1,b+2),1)= PLOAD(j,3);
        
    end
end

if NEUDL ==1 
    theta= 0.3804;
    tx= UDL(3)*cos(theta); ty= UDL(3)*sin(theta);
    l34= sqrt(abs((CORD(3,1)-CORD(4,1))^2+(CORD(3,2)-CORD(4,2))^2));
    X2= zeros(4,NDOF);
    X= l34/6*[2*tx+tx; 2*ty+ty; tx+2*tx; ty+2*ty]*0.015;
    LOAD= [3 1; 3 2; 4 1; 4 2];
    X2= [LOAD X];
    count= [1; 1; 2; 2];

    for j= 1: height(X2)
        k= 1;
        a1=X2(j,k);
        b=X2(j,k+1);
        Fg(a1+b+count(j),1)= X2(j,3);
        
    end
end
