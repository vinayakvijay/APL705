function [Kg]= elementmat( NDOF, NEN, NN, NE, ELECON, E, A, NDIM, MAT, CORD)
%K= zeros(2,2);
%for i = 1: length(E)
    %K= ((E(i,1)*A(i,1))/a(i,1))*C;
%end
Kg= zeros(NN*NDOF, NN*NDOF);

for i= 1: NE
    for l= 1:NEN
        noden= ELECON(i, l);
        for k= 1:NDOF
            j= (l-1)*NDOF+k;
            LM(i,j)= NDOF*(noden-1)+k;  %Global DOF
        end
    end
end
D= zeros( NEN, NEN);
node_points= zeros(NE, NEN);
vertex_cords= zeros(NEN, NDIM);
B= zeros( NEN, NN);
NEE= NEN*NDOF;
for i= 1: NE
    mu=MAT(i,2);
    node_points(i, :)= ELECON(i, 1:width(ELECON)-2);
    D= E(i)/(1-mu^2)*[ 1 mu 0; mu 1 0; 0 0 (1-mu)/2];
    for k=1:3
            vertex_cords(k,:) = [CORD(node_points(i,k),1); CORD(node_points(i,k),2) ];
    end
    x1= vertex_cords(1,1); y1= vertex_cords(1,2); x2= vertex_cords(2,1); y2= vertex_cords(2,2); x3= vertex_cords(3,1); y3= vertex_cords(3,2);
    B= 1/(2*A(i))*[y2-y3 0 y3-y1 0 y1-y2 0; 0 -(x2-x3) 0  -(x3-x1) 0 -(x1-x2); -(x2-x3) y2-y3 -(x3-x1) y3-y1 -(x1-x2) y1-y2];
    Ke= (B'*D*B)*A(i)* ELECON(i,5);
    for j= 1: NEE
        jg= LM(i,j);
        for l= 1: NEE
            lg= LM(i,l);
            Kg(jg, lg)= Kg(jg,lg)+Ke(j,l);
        end
    end
end

end