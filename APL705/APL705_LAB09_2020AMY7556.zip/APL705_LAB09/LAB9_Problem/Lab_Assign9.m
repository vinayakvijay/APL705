%ALL UNITS ARE IN NEWTON & metre.
clear; clc;
fileINPUT = fopen('APL705_Lab9.txt', 'r'); %Reading and initialising matrix data from .txt file.

[NN NE NM NP NIP NDIM NEN NDOF ND NL NEUDL NRC q Q K CORD ELECON BC PLOAD UDL MAT]= textRd(fileINPUT);     %Reading and initialising matrix data from .txt file.



[Wi Wj xii etaa N1 N2 N3 N4 D]= precalc(K);

Kg= elementmat( NDOF, NEN, NN, NE, ELECON, NDIM, CORD, Wi,Wj, xii, etaa, N1, N2, N3, N4, D);

[Fg]= globalforce( NDOF ,NL ,NN,PLOAD, NE, NEN, ELECON, NEUDL, UDL, CORD, Wi, Wj, xii, etaa, N1, N2, N3, N4, q, Q);
[Fg1 Kg1]= bcapplied(ND, BC, NDOF, NN, Fg, Kg);
u1=linsolve(Kg1, Fg1);

Temperture= getufromu1(BC, Fg, u1, NDOF, NN); %displacement at global nodes.

X= [CORD(1:5,1)'; CORD(6:10,1)'; CORD(11:15,1)'; CORD(16:20,1)'; CORD(21:25,1)'];
Y= [CORD(1:5,2)'; CORD(6:10,2)'; CORD(11:15,2)'; CORD(16:20,2)'; CORD(21:25,2)'];
T=[Temperture(1:5,1)'; Temperture(6:10,1)'; Temperture(11:15,1)'; Temperture(16:20,1)'; Temperture(21:25,1)'];
%contour3(X, Y, T);
%hold on;
surfc( X, Y, T);
colorbar
title('3D plot of Temperature distribution');
%R= Kg*u-Fg;   %Reaction force.


%ALL UNITS ARE IN NEWTON & metre.
