function [Fg]= globalforce(  NDOF ,NL ,NN,PLOAD, NE, NEN, ELECON, NEUDL, UDL, CORD, Wi, Wj, xii, etaa, N1, N2, N3, N4, q, Q)
Fg_flux= zeros(NN*NDOF,1);
syms xi eta;
NEE= NEN*NDOF;
Fb_temp= zeros( NEN*NDOF,1);
Fb_temp2= zeros( NEN*NDOF,1);
Fg_body = zeros(NN*NDOF,1);
Fg= zeros(NN*NDOF,1);

N= [N1 N2 N3 N4];

X= zeros(height(PLOAD),NDOF);



for i= 1: NE
    for l= 1:NEN
        noden= ELECON(i, l);
        for k= 1:NDOF
            j= (l-1)*NDOF+k;
            LM(i,j)= NDOF*(noden-1)+k;  %Global DOF
        end
    end
end

for i= 1: NE
    Bj= [diff(N1, xi) diff(N2, xi) diff(N3, xi) diff(N4, xi); diff(N1, eta) diff(N2, eta) diff(N3, eta) diff(N4, eta)];
    for z=1:NEN
        xn(z, : )=(CORD(ELECON(i,z),:)); 
    end
    Je= Bj*xn;
    
    for g=1:3
        for h= 1:3
            
            temp_J= double(subs(det(Je), [xi, eta], [xii(g), etaa(h)]));
            temp_fun=double(subs(N', [xi, eta], [xii(g), etaa(h)]));
            
            Fb_temp=Fb_temp+ temp_J*temp_fun*Wi(g)*Wj(h)*Q;
        end
        temp_fun2=double(subs(N', [xi, eta], [xii(g), 1]));
        Fb_temp2= Fb_temp2+temp_fun2*q*Wi(g);
    end
    
    
    
    for j= 1: NEE
        jg= LM(i,j);
        Fg_body(jg)= Fg_body(jg)+Fb_temp(j);
        if i>12
            Fg_flux(jg)= Fg_flux(jg)+Fb_temp2(j);
        end
    end
    Fb_temp=0;
    Fb_temp2=0;
end

Fg= Fg_body+Fg_flux;