function [Kg]= elementmat( NDOF, NEN, NN, NE, ELECON, NDIM, CORD, Wi,Wj, xii, etaa, N1, N2, N3, N4, D)
%K= zeros(2,2);
%for i = 1: length(E)
    %K= ((E(i,1)*A(i,1))/a(i,1))*C;
%end
Kg= zeros(NN*NDOF, NN*NDOF);
syms xi eta;

for i= 1: NE
    for l= 1:NEN
        noden= ELECON(i, l);
        for k= 1:NDOF
            j= (l-1)*NDOF+k;
            LM(i,j)= NDOF*(noden-1)+k;  %Global DOF
        end
    end
end
Be= zeros( NEN, 3);
xn= zeros(NEN, 2);
NEE= NEN*NDOF;
Kt=zeros(NEN*NDOF, NEN*NDOF);
for i= 1: NE
    Bj= [diff(N1, xi) diff(N2, xi) diff(N3, xi) diff(N4, xi); diff(N1, eta) diff(N2, eta) diff(N3, eta) diff(N4, eta)];
    for z=1:NEN
        xn(z, : )=(CORD(ELECON(i,z),:)); 
    end
    Je= Bj*xn;
    A= inv(Je)*Bj;
    for g=1:3
        for h= 1:3
            temp_A= double(subs(A, [xi, eta], [xii(g), etaa(h)]));
            temp_J= double(subs(det(Je), [xi, eta], [xii(g), etaa(h)]));
            Be= [temp_A(1,1), temp_A(1,2) , temp_A(1,3) , temp_A(1,4) ; temp_A(2,1) ,temp_A(2,2) ,temp_A(2,3) , temp_A(2,4)];
            f= Be'*D*Be*temp_J;
            Kt=Kt+ Wi(g)*Wj(h)*f;
        end
    end
    Ke= Kt;
    Kt=0;
    for j= 1: NEE
        jg= LM(i,j);
        for l= 1: NEE
            lg= LM(i,l);
            Kg(jg, lg)= Kg(jg,lg)+Ke(j,l);
        end
    end
end

end