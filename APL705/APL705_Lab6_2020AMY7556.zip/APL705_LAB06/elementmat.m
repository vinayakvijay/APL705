function [Kg]= elementmat( NDOF, NEN, NN, NE, ELECON, E, A, a, I)
%K= zeros(2,2);
%for i = 1: length(E)
    %K= ((E(i,1)*A(i,1))/a(i,1))*C;
%end
Kg= zeros(NN*NDOF, NN*NDOF);

for i= 1: NE
    for l= 1:NEN
        noden= ELECON(i, l);
        for k= 1:NDOF
            j= (l-1)*NDOF+k;
            LM(i,j)= NDOF*(noden-1)+k;  %Global DOF
        end
    end
end

NEE= NEN*NDOF;
for i= 1: NE
     x= ((E(i)*A(i)) /a(i));
     x2=((E(i)*I(i)) /a(i));
     y=((E(i)*I(i)) /a(i)^3);
     z=((E(i)*I(i)) /a(i)^2);
     Ke_element = [x 0 0 -x 0 0; 0 12*y 6*z 0 -12*y 6*z; 0 6*z 4*x2 0 -6*z 2*x2;  -x 0 0 x 0 0; 0 -12*y -6*z 0 12*y -6*z; 0 6*z 2*x2 0 -6*z 4*x2];
                   
    theta= ELECON(i, width(ELECON));
    if (i==1 || i==2 ||i==3)
    L= [cos(theta) sin(theta) 0 0 0 0; -sin(theta) cos(theta) 0 0 0 0; 0 0 1 0 0 0; 0 0 0 cos(theta) sin(theta) 0; 0 0 0 -sin(theta) cos(theta) 0; 0 0 0 0 0 1];
    else
    L= [cos(theta) sin(theta) 0 0 0 0; -sin(theta) cos(theta) 0 0 0 0; 0 0 1 0 0 0; 0 0 0 1 0 0; 0 0 0 0  1 0; 0 0 0 0 0 1];    
    end
    
    Ke= L'*Ke_element*L;
    for j= 1: NEE
        jg= LM(i,j);
        for l= 1: NEE
            lg= LM(i,l);
            Kg(jg, lg)= Kg(jg,lg)+Ke(j,l);
        end
    end
end

end