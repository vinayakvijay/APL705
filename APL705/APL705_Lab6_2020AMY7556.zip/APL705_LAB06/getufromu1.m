function u= getufromu1(BC, Fg, u1, NDOF, NN);
u=zeros(NN*NDOF,1);
for j= 1: height(BC)
    a= BC(j,1);
    b= BC(j,2);
    location(j,1)= (a-1)*NDOF+b;
end


b=1;
for j=1:NN*NDOF
   
    for k=1:height(location)
         if ismember(j, location)==1
         break
         else
         u(j,1)=u1(b,1);
         b=b+1;
         break;
         end

    end

end

