%ALL UNITS ARE IN NEWTON & metre.
clear; clc;
fileINPUT = fopen('APL705_Lab6.txt', 'r');       %Reading and initialising matrix data from .txt file.
[NN NE NM NP NIP NDIM NEN NDOF ND NL NEUDL NRC CORD ELECON BC PLOAD UDL MAT]= txtRd(fileINPUT);     %Reading and initialising matrix data from .txt file.


[a E A I]= precalc(NN,ELECON, CORD, MAT);

Kg= elementmat( NDOF, NEN, NN, NE, ELECON, E, A, a, I);
Fg= globalforce( NDOF ,NL ,NN,PLOAD, NEUDL, UDL, a, NE, NEN, ELECON);
[Fg1 Kg1]= bcapplied(ND, BC, NDOF, NN, Fg, Kg);
u1=linsolve(Kg1, Fg1);

u= getufromu1(BC, Fg, u1, NDOF, NN); %displacement at global nodes.

R= Kg*u-Fg   %Reaction force.


%ALL UNITS ARE IN NEWTON & metre.
