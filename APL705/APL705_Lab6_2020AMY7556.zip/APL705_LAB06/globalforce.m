function Fg= globalforce( NDOF ,NL ,NN,PLOAD, NEUDL, UDL, a, NE, NEN, ELECON)
Fg= zeros(NN*NDOF,1);



qo= UDL(NEUDL,width(UDL));
fudl= [(qo*a(2))/2; (qo*(a(2)^2))/12; (qo*a(2))/2; -(qo*(a(2)^2))/12];
PLOAD = [2, 3, fudl(2); PLOAD];
PLOAD= [2, 2, fudl(1); PLOAD];
PLOAD(3,3)= PLOAD(3,3)+fudl(3,1);
PLOAD(4,3)= PLOAD(4,3)+fudl(4,1);
X= zeros(height(PLOAD),NDOF);

for i= 1: height(PLOAD)
    for j= 1: NDOF
        X(i,j)= PLOAD(i,j);
    end
end
for i= 1: NE
    for l= 1:NEN
        noden= ELECON(i, l);
        for k= 1:NDOF
            j= (l-1)*NDOF+k;
            LM(i,j)= NDOF*(noden-1)+k;  %Global DOF
        end
    end
end
for j= 1: height(X)
        k= 1;
        a1=X(j,k);
        b=X(j,k+1);
        Fg(LM(a1,b),1)= PLOAD(j,3);
        
 end
